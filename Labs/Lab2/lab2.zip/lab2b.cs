using System;
using System.Collections.Generic;


class NoSuchElementException : System.Exception { }
class DuplicateKeyException : System.Exception { }


/*
 * MyDictionary implementa la estructura de Dictionary usando Linear Probing de
 * Open Addressing
 */
class MyDictionary
{
    /*
     * Estos son los items a ingresar en el diccionario
     * Cada item se identifica por el atributo key y tiene un valor asociado
     * en el atributo value
     */
    class Item
    {
        public string key;
        public int value;
        public bool deleted;
        public Item(string _key, int _value)
        {
            key = _key;
            value = _value;
            deleted = false;
        }
    }

    private Item[] HashTable;   // la tabla para almacenar los datos
    private int size;           // cantidad de elementos en el Dictionary
    public int Size { get { return size; } }   // getter para size

    // Modificaci�n: nuevo hash que recibe valor de M
    private int hash(string key, int M)
    {
        int res = 0;
        for (int i = 0; i < key.Length; i++)
        {
            res = (res * 31 + key[i]) % M;
        }
        return res % M;
    }

    // resize de la tabla y reindexar los items
    private void ResizeAndRehash(int newCap)
    {
        // nueva tabla
        Item[] newHashTable = new Item[newCap];
        for (int idx = 0; idx < HashTable.Length; idx++)
        {
            if (HashTable[idx] != null)
            {
                int new_idx = hash(HashTable[idx].key, newCap);  // nuevo indice


                // Modificaci�n: para buscar nuevo espacio y que no reescriba datos
                while (newHashTable[new_idx] != null && !HashTable[idx].deleted)
                {
                    new_idx++;
                    if (new_idx >= newHashTable.Length)
                        new_idx -= newHashTable.Length;
                }

                newHashTable[new_idx] = HashTable[idx];
            }
        }
        HashTable = newHashTable;    // asignar referencia a nueva tabla 
    }

    public MyDictionary()
    {
        HashTable = new Item[1];   // tabla tiene inicialmente capacidad 1
        size = 0;                  // vacio
    }

    // Agrega nuevo item con llave 'key' y valor asociado 'value'
    //   Tira excepcion DuplicateKeyException si el key ya existe
    public void Add(string key, int value)
    {
        double load_factor = size * 1.0 / HashTable.Length;
        if (load_factor > 0.5)     // chequea si ya excedio el load factor
            ResizeAndRehash(HashTable.Length * 2);

        int idx = hash(key, HashTable.Length);

        // busca celda vacia o borrada para insertar nuevo item
        while (HashTable[idx] != null && !HashTable[idx].deleted)
        {
            if (HashTable[idx].key == key)
                throw new DuplicateKeyException();
            // avanza a la proxima celda, regresando al inicio si es necesario
            idx++;
            if (idx >= HashTable.Length)
                idx -= HashTable.Length;
        }

        // agrega nuevo elemento
        HashTable[idx] = new Item(key, value);
        size++;
    }

    // Actualiza el valor asociado a key
    //   Si key no existe, lanza una excepcion
    public void Update(string key, int value)
    {
        int idx = hash(key, HashTable.Length);
        while (HashTable[idx] != null)
        {
            if (HashTable[idx].key == key)
            {
                if (!HashTable[idx].deleted)
                {
                    HashTable[idx].value = value;   // reemplaza valor
                }
            }
            // avanza a la proxima celda, regresando al inicio si es necesario
            idx++;
            if (idx >= HashTable.Length)
                idx -= HashTable.Length;
        }
    }

    public int Find(string key)
    {
        int idx = hash(key, HashTable.Length);
        while (HashTable[idx] != null)
        {
            // chequea si el key coincide
            if (HashTable[idx].key == key)
            {
                if (!HashTable[idx].deleted)
                    return HashTable[idx].value;  //  devuelvo el valor asociado
            }
            // avanza a la proxima celda, regresando al inicio si es necesario
            idx++;
            if (idx >= HashTable.Length)
                idx -= HashTable.Length;
        }
        // no encontro el elemento, entonces lanzo una excepcion
        throw new NoSuchElementException();
    }

    public void Remove(string key)
    {
        int idx = hash(key, HashTable.Length);
        while (HashTable[idx] != null)
        {
            if (HashTable[idx].key == key)
            {
                if (!HashTable[idx].deleted)
                    HashTable[idx].deleted = true;  //   lo marco borrado
                return;
            }
            // chequea si no ha sido borrado y el key coincide
            idx++;
            if (idx >= HashTable.Length)
                idx -= HashTable.Length;
        }
        // no encontro el elemento, entonces lanzo una excepcion
        throw new NoSuchElementException();
    }
}


class Lab2B
{
   public static void Main()
   {

      MyDictionary D = new MyDictionary();
      D.Add( "fish", 3 );
      D.Add( "dog", 8 );
      D.Add( "cat", 2 );
      D.Add( "pig", 10 );
      D.Add( "cow", 5 );
      D.Add( "mouse", 11 );

      try
      {
         Console.WriteLine( "OK: pig ==> {0}", D.Find("pig") );
      }
      catch (NoSuchElementException)
      {
         Console.WriteLine("ERROR: No se encontro el key pig");
      }

      try
      {
         D.Add( "pig", 7 );
         Console.WriteLine("ERROR: Se agrego el key pig de nuevo");
      }
      // Modificaci�n: DuplicateKeyException en vez de NoSuchElementException
      catch (DuplicateKeyException)
      {
         Console.WriteLine("OK: El key esta duplicado");
      }

      try
      {
         D.Remove("pig");
         Console.WriteLine("OK: key pig fue borrado");
      }
      catch (NoSuchElementException)
      {
         Console.WriteLine("ERROR: No se pudo borrar el key pig");
      }

      try
      {
         Console.WriteLine( "pig ==> {0}", D.Find("pig") );
      }
      catch (NoSuchElementException)
      {
         Console.WriteLine("OK: No se encontro el key pig");
      }


      D.Add("chicken", 13);
      D.Add("bear", 9);

      try
      {
         D.Update("cat", 25);
      }
      catch (NoSuchElementException)
      {
         Console.WriteLine("ERROR: No se pudo actualizar el valor del key cat");
      }

      try
      {
         Console.WriteLine( "OK: cat ==> {0}", D.Find("cat") );
      }
      catch (NoSuchElementException)
      {
         Console.WriteLine("ERROR: No se encontro el key cat");
      }

   }


}
