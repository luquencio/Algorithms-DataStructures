using System;



// Excepcion si no se encuentra un item en el linked list
class NoSuchElementException : System.Exception { }

// Estructura nodo del link list
class DLinkNode
{
   public int item;
   public DLinkNode prev;
   public DLinkNode next;

   public DLinkNode(int _item)
   {
      item = _item;
   }
}

/*
 * Esta implementacion de Doubly Linked List tiene la particularidad de usar
 * dos nodos dummy, uno al frente y otro en la cola de la lista.  Esto
 * simplifica el codigo porque no requiere manejar casos especiales donde
 * head == null o tail == null
 */
class DLinkList
{

    private int size;
    public int Size { get { return size; } }
    public DLinkNode head;
    public DLinkNode tail;

    public DLinkList()
    {
        head = new DLinkNode(0);   // head apunta a un nodo dummy
        tail = new DLinkNode(0);   // tail apunta al otro nodo dummy
        // los valores de estos nodos no son relevantes
        // TODO: enlazar los dos nodos
        head.next = tail;
        tail.prev = head;
    }

    // Agrega nodo que esta en la posicion justo despues de head
    public void AddFront(int item)
    {
        // TODO
        DLinkNode newNode = new DLinkNode(item);

        if (size == 0)
        {
            head.next = newNode;
            tail.prev = newNode;
        }

        else
        {
            newNode.next = head.next;
            newNode.next.prev = newNode;
            head.next = newNode;
            newNode.prev = head;
        }

        size++;
    }

    // Agrega nodo que esta en la posicion justo antes de tail
    public void AddBack(int item)
    {
        // TODO
        DLinkNode newNode = new DLinkNode(item);

        if (size == 0)
        {
            head.next = newNode;
            tail.prev = newNode;
        }

        else
        {
            newNode.prev = tail.prev;
            newNode.prev.next = newNode;
            tail.prev = newNode;
            newNode.next = tail;
        }

        size++;
    }

    // Quita nodo que esta en la posicion justo despues de head
    //   Devuelve el item grabado en ese nodo
    //   Lanza excepcion NoSuchElementException si lista esta vacia
    public int RemoveFront()
    {
        int item = head.next.item;
        DLinkNode removedNode = head.next;
        // TODO
        if (size == 0)
        {
            throw new NoSuchElementException();
        }
        else
        {
            head.next = removedNode.next;
            removedNode.next.prev = head;
        }

        size--;

        return item;
    }

    // Quita nodo justo que esta en la posicion justo antes de tail
    //   Devuelve el item grabado en ese nodo
    //   Lanza excepcion NoSuchElementException si lista esta vacia
    public int RemoveBack()
    {
        // TODO
        int item = tail.prev.item;
        DLinkNode removedNode = tail.prev;

        if (size == 0)
        {
            throw new NoSuchElementException();
        }
        else
        {
            tail.prev = removedNode.prev;
            tail.prev.next = tail;
        }

        size--;

        return item;
    }

    // Busca el item cuya llave es igual a key
    //   Retorna el nodo si lo encuentra; de lo contrario, null
    public DLinkNode Find(int item)
    {
        DLinkNode findNode = head.next;
        bool found = false;

        // TODO
        for (int i = 0; i < size - 1; i++)
        {
            if (findNode.item != item)
            {
                findNode = findNode.next;
            }

            else
            {
                found = true;
                break;
            }
        }

        return (found) ? findNode : null;
    }

    // Borrar un nodo
    public void Remove(DLinkNode node)
    {
        // TODO

        //  No se permite borrar nodo head ni tail.
        //      Lanza excepcion InvalidOperationException en ese caso
        //  Tampoco se permite borrar null
        //      Lanza excepcion ArgumentNullException en este caso

        if (node == head)
        {
            throw new InvalidOperationException();
        }

        else if (node == null)
        {
            throw new ArgumentNullException();
        }

        else
        {
            node.next.prev = node.prev;
            node.prev.next = node.next;
        }

    }

    // Concatena lista L al final de esta lista
    //   Reinicializa la lista L a una lista "vacia"
    public void Concat(DLinkList L)
    {
        // TODO
        tail.prev.next = L.head.next;
        L.head.next.prev = tail.prev;
        tail = L.tail;

        size += L.size;

        L.head = new DLinkNode(0);
        L.tail = new DLinkNode(0);

        L.head.next = tail;
        L.tail.prev = head;

        L.size = 0;
    }
}



class Lab2A
{
   public static void Main()
   {
      DLinkList L1 = new DLinkList();
      L1.AddBack(33);
      L1.AddBack(101);
      L1.AddFront(18);
      L1.AddFront(5);
      L1.AddBack(7);
      L1.AddFront(67);

      Console.WriteLine( "Se borro el nodo de la cola con item == {0}",
                         L1.RemoveBack() );
      Console.WriteLine( "Se borro el nodo del frente con item == {0}",
                         L1.RemoveFront() );

      L1.AddFront(100);
      L1.AddBack(90);

      DLinkList L2 = new DLinkList();
      L2.AddFront(4);
      L2.AddBack(80);
      L2.AddBack(23);
      L2.AddBack(32);


      Console.WriteLine("Antes de Concat   : Size de L1 = {0} y de L2 = {1}",
                        L1.Size, L2.Size);
      
      L1.Concat(L2);

      Console.WriteLine("Despues de Concat : Size de L1 = {0} y de L2 = {1}",
                        L1.Size, L2.Size);

      Console.WriteLine();

      if (L1.Find(18) != null)
         Console.WriteLine("Se encontro un nodo con item == 18");
      if (L1.Find(23) != null)
         Console.WriteLine("Se encontro un nodo con item == 23");
      if (L1.Find(3) == null)
         Console.WriteLine("No se encontro un nodo con item == 3");

      L1.Remove( L1.Find(18) );
      if (L1.Find(18) == null)
         Console.WriteLine("No se encontro un nodo con item == 18");
      if (L1.Find(101) != null)
         Console.WriteLine("Se encontro un nodo con item == 101");
      if (L1.Find(5) != null)
         Console.WriteLine("Se encontro un nodo con item == 5");

/*
 * Output Esperado:

Se borro el nodo de la cola con item == 7
Se borro el nodo del frente con item == 67
Antes de Concat   : Size de L1 = 8 y de L2 = 4
Despues de Concat : Size de L1 = 12 y de L2 = 0

Se encontro un nodo con item == 18
Se encontro un nodo con item == 23
No se encontro un nodo con item == 3
No se encontro un nodo con item == 18
Se encontro un nodo con item == 101
Se encontro un nodo con item == 5

*/
   }
}
