using System;
using System.Collections.Generic;


class NoSuchElementException : System.Exception {}

class MyPriorityQueue
{
    private List<int> heap;

    public MyPriorityQueue()
    {
        heap = new List<int>();
        heap.Add(0);      // agregando un item dummy en la posicion 0
        // esto es para facilitar los calculos de los indices
        // para los nodos padres e hijos
    }

    // Size devuelve la cantidad de items en el Priority Queue
    public int Size
    {
        get
        {
            // TODO
            return (heap.Count - 1);
        }
    }

    // Inspecciona el elemento en la "cabeza" del priority queue
    public int Peek()
    {
        if (Size == 0)
            throw new NoSuchElementException();
        return heap[1];    // root siempre esta en la posicion 1
    }

    // Operacion de subir en el arbol y revisar que se cumpla las propiedades
    //   del binary heap
    private void UpHeap(int cur)
    {
        // asumimos que el nodo en el indice cur existe

        while (cur > 1)         // mientras no hemos llegado a la raiz
        {
            int par = cur / 2;   // parent
            // TODO: si la condicion del heap se cumple, no hay mas que hacer:
            //          detenemos el loop
            if (heap[cur] >= heap[par])
            {
                break;
            }

            // TODO: swap de los nodos en los indices cur y par
            int temp = heap[cur];
            heap[cur] = heap[par];
            heap[par] = temp;

            // TODO: sube en el arbol hacia el padre
            cur = par;
        }
    }

    // Operacion de bajar en el arbol y revisar que se cumpla las propiedades
    //   del binary heap
    private void DownHeap(int cur)
    {
        // asumimos que el nodo en cur existe

        while (true)
        {
            int left = cur * 2;       // indice del hijo izquierdo
            int right = cur * 2 + 1;   // indice del hijo derecho

            // TODO: si no tiene hijos, llegamos al nivel mas bajo del arbol:
            //          detenemos el loop
            if (left > Size)
            {
                break;
            }

            int min_idx;
            // TODO: min_idx es el indice (left o right) del hijo mas prioritario
            if (right <= Size)
            {
                min_idx = (heap[left] <= heap[right]) ? left : right;
            }

            else
            {
                min_idx = left;
            }


            // TODO: revisar si la propiedad de heap se cumple para los nodos
            //       en los indices cur y min_idx.  Si no nay violacion del heap,
            //       terminamos el loop
            if (heap[cur] <= heap[min_idx])
            {
                break;
            }

            // TODO: swap de los nodos en los indices cur y min_idx
            int temp = heap[cur];
            heap[cur] = heap[min_idx];
            heap[min_idx] = temp;

            // TODO: navego hacia abajo en el arbol
            cur = min_idx;
        }
    }

    // Agrega _item en la cola
    public void Enqueue(int _item)
    {
        // TODO: agregar _item al final del binary heap
        heap.Add(_item);

        UpHeap(Size);   // corregir condicion heap desde el ultimo nodo insertado
        //   hasta la raiz
    }

    // Extrae el _item con mayor prioridad (menor valor) de la cola
    public int Dequeue()
    {
        if (Size == 0)
            throw new NoSuchElementException();

        int ret = heap[1];  // grabo una copia para el return final

        // TODO: reemplaza la raiz con el ultimo nodo
        heap[1] = heap[Size];

        // TODO: borra el ultimo nodo
        heap.RemoveAt(Size);

        DownHeap(1);   // corregir condicion heap desde la raiz hacia abajo

        return ret;
    }

    // Actualiza el valor del nodo en el indice cur
    //   Como este valor determina la prioridad, debemos corregir la propiedad
    //   heap si se viola
    // Si cur es un indice de un nodo inexistente,
    //   tira excepcion NoSuchElementException
    public void Update(int cur, int _item)
    {
        // TODO
        if (cur > Size)
        {
            throw new NoSuchElementException();
        }

        heap[cur] = _item;
        UpHeap(cur);
        DownHeap(cur);
    }

    // Determina el indice del nodo "hermano" del indice cur
    //   Si no existe, tira excepcion NoSuchElementException
    public int Sibling(int cur)
    {
        // TODO
        int par = cur / 2;
        int sibling = ((par * 2) == cur) ? par * 2 + 1 : par * 2;

        if (par == 0 || cur > Size || sibling > Size)
        {
            throw new NoSuchElementException();
        }

        return sibling;
    }
}

class Lab4B {
   public static void Main() {
      MyPriorityQueue PQ = new MyPriorityQueue();
      PQ.Enqueue(37);
      PQ.Enqueue(50);
      PQ.Enqueue(4);
      PQ.Enqueue(65);
      PQ.Enqueue(89);
      PQ.Enqueue(60);
      PQ.Enqueue(4);
      PQ.Enqueue(5);
      
      Console.WriteLine( PQ.Dequeue() );

      Console.WriteLine( PQ.Dequeue() );
      Console.WriteLine( PQ.Dequeue() );
      Console.WriteLine( PQ.Dequeue() );
      Console.WriteLine( PQ.Dequeue() );

      PQ.Enqueue(10);
      PQ.Enqueue(2);
      Console.WriteLine( PQ.Dequeue() );

/*
Expected output:
4
4
5
37
50
2
*/      

   }
}
