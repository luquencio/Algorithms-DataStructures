/*
TODO: En este ejercicio, reemplacen la estructura de datos indicadas con
      la proveida por C#.  Obviamente, cada metodo debe ser reemplazado
      por el equivalente de la libreria de C#.  Si C# no provee una estructura
      de datos o un metodo adecuado para el reemplazo, indicalo en un comentario.
*/

using System;
using System.Collections.Generic;   // HINT: esta libreria debe contener todo lo que uds. necesitan

class Lab4A
{
   public static void Main() {
      Test_DynamicArray();
      Test_LinkedList();
      Test_Stack();
      Test_Queue();
      Test_PriorityQueue();
      Test_Dictionary();
      Test_BalancedBST();
   }

   static void Test_DynamicArray()
   {
       // TODO: Reemplazar MyDynamicArray => List y todas estas operaciones
       //MyDynamicArray A = new MyDynamicArray();
       //A.AddBack(75);
       //A.AddBack(12);
       //A.AddBack(52);
       //A.AddBack(2);
       //A.AddBack(0);
       //A.AddBack(19);
       //A.RemoveBack();
       //A.RemoveBack();
       //A.AddBack(7);
       //Console.WriteLine(A.Size);
       //Console.WriteLine(A[3]);            // indexing operation

       List<int> A = new List<int>();
       A.Add(75);
       A.Add(12);
       A.Add(52);
       A.Add(2);
       A.Add(0);
       A.Add(19);

       // list (DynamicArray) de c# no tiene un metodo que elimine el ultimo elemento directamente
       // pero se puede hacer como:
       A.Remove(A.Count);
       A.Remove(A.Count);


       A.Add(7);
       Console.WriteLine(A.Count);
       Console.WriteLine(A[3]);
   }

   static void Test_LinkedList()
   {
       // TODO: Reemplazar MyLinkedList => LinkedList y todas estas operaciones
       //MyLinkedList L = new LinkedList();
       //L.AddFront(3);
       //L.AddBack(6);
       //L.AddBack(4);
       //L.AddBack(2);
       //L.AddBack(10);
       //L.AddBack(0);
       //L.RemoveFront();
       //L.RemoveFront();
       //L.RemoveFront();
       //L.RemoveBack();
       //L.AddBack(4);
       //L.AddBack(7);
       //Console.WriteLine(L.Size);
       //Console.WriteLine(L.Front());
       //Console.WriteLine(L.Back());

       LinkedList<int> L = new LinkedList<int>();
       L.AddFirst(3);
       L.AddLast(6);
       L.AddLast(4);
       L.AddLast(2);
       L.AddLast(10);
       L.AddLast(0);
       L.RemoveFirst();
       L.RemoveFirst();
       L.RemoveFirst();
       L.RemoveLast();
       L.AddLast(4);
       L.AddLast(7);
       Console.WriteLine(L.Count);
       Console.WriteLine(L.First.Value);
       Console.WriteLine(L.Last.Value);

   }

   static void Test_Stack()
   {
       // TODO: Reemplazar MyStack => Stack y todas estas operaciones
       //MyStack S = new Stack();
       //S.Push(0);
       //S.Push(90);
       //S.Push(78);
       //S.Push(4);
       //S.Push(10);
       //S.Push(4);
       //Console.WriteLine(S.Size);
       //Console.WriteLine(S.Pop());
       //S.Push(7);
       //S.Push(10);
       //Console.WriteLine(S.Pop());

       Stack<int> S = new Stack<int>();
       S.Push(0);
       S.Push(90);
       S.Push(78);
       S.Push(4);
       S.Push(10);
       S.Push(4);
       Console.WriteLine(S.Count);
       Console.WriteLine(S.Pop());
       S.Push(7);
       S.Push(10);
       Console.WriteLine(S.Pop());

   }

   static void Test_Queue()
   {
       // TODO: Reemplazar MyQueue => Queue y todas estas operaciones
       //MyQueue Q = new Queue();
       //Q.Enqueue(33);
       //Q.Enqueue(1);
       //Q.Enqueue(50);
       //Q.Enqueue(4);
       //Q.Enqueue(5);
       //Q.Dequeue();
       //Q.Enqueue(6);
       //Console.WriteLine(Q.Peek());
       //Q.Dequeue();
       //Console.WriteLine(Q.Size);
       //Console.WriteLine(Q.Dequeue());

       Queue<int> Q = new Queue<int>();
       Q.Enqueue(33);
       Q.Enqueue(1);
       Q.Enqueue(50);
       Q.Enqueue(4);
       Q.Enqueue(5);
       Q.Dequeue();
       Q.Enqueue(6);
       Console.WriteLine(Q.Peek());
       Q.Dequeue();
       Console.WriteLine(Q.Count);
       Console.WriteLine(Q.Dequeue());

   }

   static void Test_PriorityQueue()
   {
       // No existe estrutura de datos parecida a priority queue

       // TODO: Reemplazar PriorityQueue => ??? y todas estas operaciones
       //MyPriorityQueue PQ = new MyPriorityQueue();
       //Q.Enqueue(33);
       //Q.Enqueue(1);
       //Q.Enqueue(50);
       //Q.Enqueue(4);
       //Q.Enqueue(5);
       //Q.Dequeue();
       //Q.Enqueue(6);
       //Console.WriteLine(Q.Peek());
       //Q.Dequeue();
       //Console.WriteLine(Q.Size);
       //Console.WriteLine(Q.Dequeue());
   }

   static void Test_Dictionary()
   {
       // TODO: Reemplazar MyDictionary => Dictionary y todas estas operaciones
       //MyDictionary D = new MyDictionary();
       //D.Add("hello", 3);
       //D.Add("world", 1);
       //D.Add("hello world", 0);
       //D.Add("xyz", 10);
       //D.Add("ins207", 3);
       //D.Add("this lab is easy", 6);
       //D.Remove("xyz");
       //Console.WriteLine(D.Size);
       //Console.WriteLine(D.Find("ins207"));

       Dictionary<string, int> D = new Dictionary<string, int>();
       D.Add("hello", 3);
       D.Add("world", 1);
       D.Add("hello world", 0);
       D.Add("xyz", 10);
       D.Add("ins207", 3);
       D.Add("this lab is easy", 6);
       D.Remove("xyz");
       Console.WriteLine(D.Count);

       // el dictionary de C# no contiene un metodo devuelva el valor mediante un key
       // pero se puede usar el index operator
       Console.WriteLine(D["ins207"]);


       //try
       //{
       //    D.add("ins207", 6);
       //}
       //catch (duplicatekeyexception)
       //{
       //    console.writeline("duplicado");
       //}

       try
       {
           D.Add("ins207", 6);
       }
       catch (ArgumentException)
       {
           Console.WriteLine("duplicado");
       }

       D["ins207"] = 10;                     // indexing operator

       //try
       //{
       //    int val = D.Find("ins207");
       //    Console.WriteLine(val);
       //}
       //catch (DuplicateKeyException)
       //{
       //    Console.WriteLine("No existe");
       //}

       try
       {
           // el dictionary de C# no contiene un metodo devuelva el valor mediante un key
           // pero se puede usar el index operator
           int val = D["ins207"];
           Console.WriteLine(val);
       }
       catch (KeyNotFoundException)
       {
           Console.WriteLine("No existe");
       }


       // TODO: Iteren sobre los elementos de Dictionary, imprimiendo cada key
       //       con su valor asociado
       foreach (var key in D.Keys)
       {
           Console.WriteLine("Key: {0} ---> Valor: {1}", key, D[key]);
       }
   }

   static void Test_BalancedBST()
   {
       // TODO: Reemplazar Balanced BST => ??? y todas estas operaciones      

       //MyBalancedBST T = new MyBalancedBST();
       //T.Add(100);
       //T.Add(32);
       //T.Add(61);
       //T.Add(3);
       //T.Add(0);
       //T.Add(8);
       //T.Add(90);
       //T.Add(134);
       //T.Add(17);
       //T.Remove(134);
       //T.Remove(32);
       //T.Add(67);
       //Console.WriteLine(T.Size);


       // El SortedSet es muy parecido a BST 

       SortedSet<int> T = new SortedSet<int>();
       T.Add(100);
       T.Add(32);
       T.Add(61);
       T.Add(3);
       T.Add(0);
       T.Add(8);
       T.Add(90);
       T.Add(134);
       T.Add(17);
       T.Remove(134);
       T.Remove(32);
       T.Add(67);
       Console.WriteLine(T.Count);


       // asume que Find() devuelve true si encuentra el item, false de lo contrario
       //if (T.Find(3))
       //    Console.WriteLine("Se encontro el item 3 en el arbol");
       //if (!T.Find(32))
       //    Console.WriteLine("No se encontro el item 32 en el arbol");

       if (T.Contains(3))
           Console.WriteLine("Se encontro el item 3 en el arbol");
       if (!T.Contains(32))
           Console.WriteLine("No se encontro el item 32 en el arbol");

       T.Add(100);         // Q: que pasaria con este Add de un key duplicado?

       //Console.WriteLine("El item minimo en el arbol es: {0}", T.Min());
       //Console.WriteLine("El item maximo en el arbol es: {0}", T.Max());

       Console.WriteLine("El item minimo en el arbol es: {0}", T.Min);
       Console.WriteLine("El item maximo en el arbol es: {0}", T.Max);

       // no posee ningun metodo que realice la funcion de successor y predecessor
       //Console.WriteLine("Successor de 13 es: {0}", T.Successor(13));
       //Console.WriteLine("Predecessor de 13 es: {0}", T.Predecessor(13));

       // no posee ningun metodo que realice algo como rank
       //Console.WriteLine("Rank de 17 en el arbol es: {0}", T.Rank(17));


       //Console.WriteLine("El item en la posicion 5 del arbol es: {0}", T.Select(5));            
       Console.WriteLine("El item en la posicion 5 del arbol es: {0}", T.ElementAt(5));

       // TODO: Iteren sobre los elementos de MyBalancedBST, imprimiendo cada key
       //       con su valor asociado
       foreach (var item in T)
       {
           Console.WriteLine(item);
       }
   }
}
