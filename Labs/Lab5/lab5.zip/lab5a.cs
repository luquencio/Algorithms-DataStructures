using System;
using System.Collections.Generic;

/*
 * NOTE: En esta parte del laboratorio, se permite consultar Internet
 * Para este ejercicio, no pueden usar LINQ 
 */


/*
 * En el primer laboratorio, creamos una clase similar a este para grabar
 * los scores en un video juego.  Extendemos esta clase para incluir mas
 * atributos. 
 */

class GameScore : IComparable<GameScore>
{
    public string Name { get; private set; }
    public DateTime Date { get; private set; }
    public long Score { get; private set; }
    public int Level { get; private set; }
    public GameScore(string name, DateTime date, long score, int level)
    {
        Name = name;
        Date = date;
        Score = score;
        Level = level;
    }

    public int CompareTo(GameScore other)
    {
        // If other is not a valid object reference, this instance is greater. 
        if (other == null) return 1;

        else if (Score.CompareTo(other.Score) != 0)
        {
            return Score.CompareTo(other.Score) * (-1);
        }

        else if (Level.CompareTo(other.Level) != 0)
        {
            return Level.CompareTo(other.Level) * (-1);
        }

        else if (Date.CompareTo(other.Date) != 0)
        {
            return Date.CompareTo(other.Date);
        }

        else
        {
            return Name.CompareTo(other.Name);
        }
    }


}

class GameScoreDescScoreComparer : IComparer<GameScore>
{
    public int Compare(GameScore a, GameScore b)
    {
        if (a.Score == b.Score)
        {
            return 0;
        }

        else if (a.Score < b.Score)
        {
            return 1;
        }

        else
        {
            return -1;
        }
    }
}

class GameScoreAscScoreComparer : IComparer<GameScore>
{
    public int Compare(GameScore a, GameScore b)
    {
        if (a.Score == b.Score)
        {
            return 0;
        }

        else if (a.Score < b.Score)
        {
            return -1;
        }

        else
        {
            return 1;
        }
    }
}

class GameScoreNameAscComparer : IComparer<GameScore>
{
    public int Compare(GameScore a, GameScore b)
    {
        if (a.Name.ToLower().CompareTo(b.Name.ToLower()) == 0)
        {
            return 0;
        }

        else if (a.Name.ToLower().CompareTo(b.Name.ToLower()) < 0)
        {
            return -1;
        }

        else
        {
            return 1;
        }
    }
}

class GameScoreDescDateComparer : IComparer<GameScore>
{
    public int Compare(GameScore a, GameScore b)
    {
        if (a.Date.CompareTo(b.Date) == 0)
        {
            return 0;
        }

        else if (a.Date.CompareTo(b.Date) < 0)
        {
            return 1;
        }

        else
        {
            return -1;
        }
    }
}

class GameScoreDescLevelComparer : IComparer<GameScore>
{
    public int Compare(GameScore a, GameScore b)
    {
        if (a.Level == b.Level)
        {
            return 0;
        }

        else if (a.Level < b.Level)
        {
            return 1;
        }

        else
        {
            return -1;
        }
    }
}

class Lab5a {
   public static void Main()
   {
       // Creamos una lista de GameScore
       List<GameScore> L = new List<GameScore>();

       // Agregamos algunos datos
       L.Add(new GameScore("haxor", new DateTime(2010, 3, 20), 987654, 9));
       L.Add(new GameScore("user", new DateTime(2012, 12, 31), 345565, 5));
       L.Add(new GameScore("Mario", new DateTime(2012, 11, 5), 54675, 2));
       L.Add(new GameScore("Luigi", new DateTime(2013, 1, 7), 3003, 1));
       L.Add(new GameScore("xXx", new DateTime(2013, 4, 30), 12345, 3));
       L.Add(new GameScore("t-rex", new DateTime(2009, 10, 15), 155555, 3));
       L.Add(new GameScore("12345", new DateTime(2012, 3, 4), 12345, 5));
       L.Add(new GameScore("54321", new DateTime(2012, 3, 4), 12345, 5));
       L.Add(new GameScore("otro", new DateTime(2012, 2, 4), 12345, 5));
       L.Add(new GameScore("la_bestia", new DateTime(2012, 1, 4), 12345, 4));


       // TODO: Ordenar por score descendente
       // HINT: Implementa un Comparer o un delegate
       L.Sort(new GameScoreDescScoreComparer());
       Print(L);


       //TODO: Ordenar por nombre ascendente
       // HINT: Implementa un Comparer o un delegate
       L.Sort(new GameScoreAscScoreComparer());
       Print(L);


       // TODO: Ordenar por nombre ascendente ignorando mayusculas vs minusculas
       // HINT: Implementa un Comparer o un delegate
       L.Sort(new GameScoreNameAscComparer());
       Print(L);



       // TODO: Ordenar por fecha descendente
       // HINT: Implementa un Comparer o un delegate
       L.Sort(new GameScoreDescDateComparer());
       Print(L);


       // TODO: Ordenar por nivel descendente
       // HINT: Implementa un Comparer o un delegate
       L.Sort(new GameScoreDescLevelComparer());
       Print(L);

       //// TODO: Ordenar por el "orden natural" de los GameScore.
       //// HINT: Implementar la interfaz IComparable
       ////    primero por score descendente; si hay empate, por level descendente;
       ////    si sigue empate, por fecha ascendente; si sigue el empate, por nombre
       L.Sort();
       Print(L);

   }

   static void Print(List<GameScore> L)
   {
      foreach (GameScore g in L)
      {
         Console.WriteLine("{0} {1} {2} {3}", g.Name, g.Date, g.Score, g.Level);
      }
   }
}

