using System;
using System.Collections.Generic;

class Sort
{
    // MinMaxSelectionSort es similar a Selection Sort, excepto que,
    // en cada iteracion, buscamos simultaneamente el minimo y el maximo elemento
    // * El minimo lo colocamos al inicio del arreglo
    // * El maximo lo colocamos al final del arreglo
    // Para reducir un poco la cantidad de comparaciones, usen el hecho de que:
    //   si x < min, x no puede ser mayor que max
    public static void MinMaxSelectionSort(int[] A)
    {


        // TODO: implementar el algoritmo descrito arriba
        for (int i = 0; i < A.Length - i; i++)
        {
            int min = i, max = i, temp = 0;

            for (int j = i + 1; j < A.Length - i; j++)
            {
                if (A[j] < A[min])
                {
                    min = j;
                    continue;
                }

                else if (A[j] > A[max])
                {
                    max = j;
                }
            }

            if (A[min] != A[i])
            {
                temp = A[i];
                A[i] = A[min];
                A[min] = temp;
            }

            if (A[max] != A[A.Length - 1 - i])
            {
                temp = A[A.Length - 1 - i];
                A[A.Length - 1 - i] = A[max];
                A[max] = temp;
            }
        }
    }



    // BidirBubbleSort es una variante de Bubble Sort, donde la primera iteracion
    // avanzamos desde el inicio, la segunda iteracion va desde el final hacia
    // adelante, y asi alternandose hasta que quede ordenado.

    // Mantendremos dos indices L y R, donde [L, R] es el rango de elementos que
    // aun no han sido ordenados.  Inicialmente L = 0, R = N-1.

    // En las iteraciones impares (comenzandos desde 1), vamos hacia delante,
    // desde L a R, ejecutando el mismo algorithmo de la burbuja; en las
    // iteraciones pares, vamos hacia atras desde R a L haciendo la burbuja.

    // Al final de las iteraciones de esa primera iteracion, ajustamos el indice
    // L o R (dependiendo de la iteracion) al ultimo indice donde hicimos swap.

    // La objetivo de esto es que todos los elementos "mas alla" a la posicion
    // del ultimo swap ya estan ordenados y no hay que procesarlos.

    public static void BidirBubbleSort(int[] A)
    {
        // TODO: implementen lo descrito anteriormente
        int iteracion = 1;
        int L = 0;
        int R = A.Length - 1;
        bool didSwap;
        int temp;

        do
        {
            didSwap = false;

            if (iteracion % 2 != 0)
            {
                for (int i = L, j = i + 1; j <= R; i++, j++)
                {
                    if (A[j] < A[i])
                    {
                        temp = A[i];
                        A[i] = A[j];
                        A[j] = temp;
                        didSwap = true;
                    }
                }

                R--;
            }

            else
            {
                for (int i = R, j = i - 1; j >= L; i--, j--)
                {
                    if (A[j] > A[i])
                    {
                        temp = A[i];
                        A[i] = A[j];
                        A[j] = temp;
                        didSwap = true;
                    }
                }

                L++;
            }

            iteracion++;


        } while (didSwap);
    }

}

class Lab5b {

   public static void Main()
   {
      int[] A1 = { 4, 33, -5, 3, 0, -10, -13, 3, -5, 8, 4, 6, -5, 0 };
      Sort.MinMaxSelectionSort(A1);
      Print(A1);
      // Debe imprimir:
      // -13 -10 -5 -5 -5 0 0 3 3 4 4 6 8 33

      int[] A2 = { 3, 5, 3, 1, 3, -5, 4, 6, 7, 8 };      
      Sort.BidirBubbleSort(A2);
      Print(A2);
      // Debe imprimir:
      // -5 1 3 3 3 4 5 6 7 8

      compare(A1, A2);
   // Resultado esperado:
   //    Falta en A2: -13 -10 -5 -5 0 0 4 33
   //    Falta en A1: 1 3 5 7
   }

   static void Print(int[] A)
   {
      foreach (int x in A)
      {
         Console.Write("{0} ", x);
      }
      Console.WriteLine();
   }


   // Una vez que los datos estan ordenados, podemos "comparar" las dos
   // listas: Queremos determinar cuales elementos existen en la lista A1,
   // pero no existen en A2, y viceversa
   static void compare(int[] A1, int[] A2)
   {
       // TODO: Implementar la comparacion indicada.  Imprime:
       //       1) los datos presentes en A1 y que no se encuentra en A2
       //       2) los datos presentes en A2 y que no se encuentra en A1
       //       En caso de datos duplicados, ambas listas deben tener exactamente
       //       la misma cantidad; de lo contrario, deben reportar los que falten.
       //       La complejidad de tu algoritmo debe ser O(N)

       int i = 0;
       int j = 0;
       LinkedList<int> faltanA1 = new LinkedList<int>();
       LinkedList<int> faltanA2 = new LinkedList<int>();


       while (true)
       {
           if (A1[i] < A2[j])
           {
               faltanA2.AddLast(A1[i]);
               i++;
           }

           else if (A1[i] > A2[j])
           {
               faltanA1.AddLast(A2[j]);
               j++;
           }

           else
           {
               i++;
               j++;
           }

           if (i == A1.Length)
           {
               for (int k = j; k < A2.Length; k++)
               {
                   faltanA1.AddLast(A2[k]);
               }

               break;
           }

           else if (j == A2.Length)
           {
               for (int k = i; k < A1.Length; k++)
               {
                   faltanA2.AddLast(A1[k]);
               }

               break;
           }
       }

       Console.Write("Faltan en A2: ");
       foreach (int num in faltanA2)
       {
           Console.Write("{0} ", num);
       }

       Console.WriteLine();

       Console.Write("Faltan en A1: ");
       foreach (int num in faltanA1)
       {
           Console.Write("{0} ", num);
       }

       Console.WriteLine();

   }

}
